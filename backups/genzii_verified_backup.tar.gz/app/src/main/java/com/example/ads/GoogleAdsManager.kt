package com.example.ads

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.GenziiRepository
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Manages Google Test Ads and rewarded feature unlocking in Genzii.
 * Uses official Google AdMob test ad unit identifiers.
 */
object GoogleAdsManager {
  // Official Google AdMob Test Ad Unit IDs
  const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"
  const val BANNER_TEST_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
  const val REWARDED_TEST_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
  const val INTERSTITIAL_TEST_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"

  private val _totalAdsWatched = MutableStateFlow(0)
  val totalAdsWatched = _totalAdsWatched.asStateFlow()

  private val _bonusScansEarned = MutableStateFlow(0)
  val bonusScansEarned = _bonusScansEarned.asStateFlow()

  /**
   * Adds rewarded bonus scans and chat tokens to the user's reactive session.
   */
  fun grantReward(scansCount: Int = 10, aiCredits: Int = 10) {
    _totalAdsWatched.update { it + 1 }
    _bonusScansEarned.update { it + scansCount }
    GenziiRepository.grantRewardedBonus(scansCount, aiCredits)
  }
}

/**
 * Standard Google Mobile Ads Test Banner Composable (320x50dp standard banner).
 */
@Composable
fun GoogleTestBannerAd(
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .height(60.dp)
      .testTag("google_test_banner_ad"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F3F4)),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDADCE0))
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f)
      ) {
        // "Ad" badge matching Google styling
        Surface(
          shape = RoundedCornerShape(4.dp),
          color = Color(0xFFFBBC04)
        ) {
          Text(
            text = "Ad",
            color = Color.Black,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
          )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column {
          Text(
            text = "Google Cloud • Gemini API for Android",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF202124),
            maxLines = 1
          )
          Text(
            text = "Test Ad (${GoogleAdsManager.BANNER_TEST_AD_UNIT_ID.takeLast(10)})",
            fontSize = 10.sp,
            color = Color(0xFF5F6368),
            maxLines = 1
          )
        }
      }

      // AdChoices / Info icon
      Icon(
        imageVector = Icons.Default.Info,
        contentDescription = "Ad Info",
        tint = Color(0xFF5F6368),
        modifier = Modifier.size(16.dp)
      )
    }
  }
}

/**
 * Interactive Full-Screen Google Rewarded Video Test Ad Dialog.
 * Simulates the 5-second AdMob rewarded video experience with reward callback.
 */
@Composable
fun GoogleTestRewardedAdDialog(
  onDismiss: () -> Unit,
  onRewardEarned: (scans: Int, credits: Int) -> Unit
) {
  var secondsRemaining by remember { mutableStateOf(5) }
  var isRewarded by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    while (secondsRemaining > 0) {
      delay(1000L)
      secondsRemaining -= 1
    }
    isRewarded = true
    GoogleAdsManager.grantReward(scansCount = 10, aiCredits = 10)
    onRewardEarned(10, 10)
  }

  Dialog(
    onDismissRequest = {
      if (isRewarded) onDismiss()
    },
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black.copy(alpha = 0.95f))
        .padding(20.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp))
          .background(Color(0xFF1E1E2E))
          .border(1.dp, Color(0xFF43435C), RoundedCornerShape(24.dp))
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFFFBBC04)
          ) {
            Text(
              text = "Google Test Ad",
              color = Color.Black,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }

          if (isRewarded) {
            IconButton(
              onClick = onDismiss,
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.15f))
            ) {
              Icon(Icons.Default.Close, contentDescription = "Close Ad", tint = Color.White)
            }
          } else {
            Text(
              text = "Reward in ${secondsRemaining}s",
              color = Color.White.copy(alpha = 0.8f),
              fontSize = 13.sp,
              fontWeight = FontWeight.Medium
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Ad Creative Mockup
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
              androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(GenziiPurpleDark, GenziiPurple)
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(16.dp)
          ) {
            Icon(
              imageVector = Icons.Filled.WorkspacePremium,
              contentDescription = null,
              tint = Color(0xFFFFD700),
              modifier = Modifier.size(54.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Genzii AI Cloud Architecture",
              color = Color.White,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Smart originality checking powered by Gemini",
              color = Color.White.copy(alpha = 0.8f),
              fontSize = 12.sp,
              textAlign = TextAlign.Center
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Timer Progress Indicator
        LinearProgressIndicator(
          progress = { (5 - secondsRemaining) / 5f },
          modifier = Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp)),
          color = Color(0xFF34A853),
          trackColor = Color.White.copy(alpha = 0.15f)
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (isRewarded) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFF34A853).copy(alpha = 0.2f))
              .padding(horizontal = 16.dp, vertical = 10.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = Color(0xFF34A853),
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Reward Earned: +10 Free Scans & +10 AI Credits!",
              color = Color(0xFF81C995),
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp
            )
          }

          Spacer(modifier = Modifier.height(18.dp))

          Button(
            onClick = onDismiss,
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GenziiPurple),
            shape = RoundedCornerShape(14.dp)
          ) {
            Text(
              text = "Collect Reward & Continue",
              fontFamily = PoppinsFontFamily,
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp
            )
          }
        } else {
          Text(
            text = "Watch this test ad to earn 10 free scans without any payment.",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 12.sp,
            textAlign = TextAlign.Center
          )
        }
      }
    }
  }
}

/**
 * Interactive Full-Screen Google Interstitial Test Ad Dialog.
 * Simulates standard Google AdMob Interstitial Ad with skip countdown and close button.
 */
@Composable
fun GoogleTestInterstitialAdDialog(
  onDismiss: () -> Unit
) {
  var secondsRemaining by remember { mutableStateOf(3) }
  var canSkip by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    while (secondsRemaining > 0) {
      delay(1000L)
      secondsRemaining -= 1
    }
    canSkip = true
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black.copy(alpha = 0.92f))
        .padding(20.dp),
      contentAlignment = Alignment.Center
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(24.dp))
          .background(Color(0xFF1E1E2E))
          .border(1.dp, Color(0xFF43435C), RoundedCornerShape(24.dp))
          .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFFFBBC04)
          ) {
            Text(
              text = "Google Test Ad",
              color = Color.Black,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            if (!canSkip) {
              Text(
                text = "Close in ${secondsRemaining}s",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp
              )
              Spacer(modifier = Modifier.width(8.dp))
            }

            IconButton(
              onClick = onDismiss,
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.15f))
                .testTag("close_interstitial_ad_button")
            ) {
              Icon(Icons.Default.Close, contentDescription = "Close Ad", tint = Color.White)
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Interstitial Ad Creative
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
              androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(Color(0xFF2B1055), GenziiPurple)
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(16.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CloudQueue,
              contentDescription = null,
              tint = Color(0xFF64B5F6),
              modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "Google Cloud AI Platform",
              color = Color.White,
              fontSize = 17.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Next-generation multimodal reasoning and secure cloud processing.",
              color = Color.White.copy(alpha = 0.85f),
              fontSize = 12.sp,
              textAlign = TextAlign.Center
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
          text = "AdMob Unit: ${GoogleAdsManager.INTERSTITIAL_TEST_AD_UNIT_ID}",
          color = Color.White.copy(alpha = 0.5f),
          fontSize = 10.sp,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(20.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier
              .weight(1f)
              .height(48.dp),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
          ) {
            Text(
              text = "Skip",
              color = Color.White,
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium
            )
          }

          Button(
            onClick = onDismiss,
            modifier = Modifier
              .weight(1f)
              .height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GenziiPurple),
            shape = RoundedCornerShape(14.dp)
          ) {
            Text(
              text = "Continue",
              fontFamily = PoppinsFontFamily,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          }
        }
      }
    }
  }
}

